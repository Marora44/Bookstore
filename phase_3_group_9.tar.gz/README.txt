Group Members:

Mundeep Arora
Kyle Savoie
Brent Garey


Notes:

Make sure url in strings.xml points to folder containing php files (phase3)